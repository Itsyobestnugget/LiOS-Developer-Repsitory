To add an icon simply add a .png, .ico, or .svg file to AppTemplate/App Icon/
if its a PNG we will turn it into an .ICO or if you want it to be a vector just write i want it to be a vector image at the bottom of this document

Difference between Ico and SVG 

Ico - Standard bitmap format will get less quality the bigger it is

Svg - not bitmap wont lose its quality no matter how much its zoomed in (good for detailed icons that are small)





