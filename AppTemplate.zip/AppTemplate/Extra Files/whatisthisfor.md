this extra files section is where you put things like

- images that arnt the icon

- extra files or base files if its some sort of make-something-using-a-template sort of thing

- Videos and audio for sound effects ect



how to call a file using html

When calling a file or displaying an image you call the file by doing so below (this html is for calling an image)

<img src="grass.png">

or get it using a link like so

<img src="https://i.pinimg.com/originals/bd/cb/64/bdcb6414071ce880f3fa1dc18e2eda5b.png">

src = Source of file

